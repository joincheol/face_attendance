const video = document.getElementById('video')

//face-api불러오면 웹캠 실행 함수 샐행
Promise.all([
    faceapi.nets.tinyFaceDetector.loadFromUri('/models'),
    faceapi.nets.faceRecognitionNet.loadFromUri('/models')
]).then(startVideo)

//웹캠 실행
function startVideo() {
    navigator.getUserMedia(
        { video: {} },
        stream => video.srcObject = stream,
        err => console.error(err)
    )
}

// 얼굴 인식 및 표시
video.addEventListener('play', () => {
    const canvas = faceapi.createCanvasFromMedia(video);
    const page1Div = document.getElementById('page1');
    page1Div.appendChild(canvas);
    const displaySize = { width: video.width, height: video.height };
    faceapi.matchDimensions(canvas, displaySize);

    setInterval(async () => {
        const detections = await faceapi.detectAllFaces(video, new faceapi.TinyFaceDetectorOptions());
        canvas.getContext('2d').clearRect(0, 0, canvas.width, canvas.height);
        faceapi.draw.drawDetections(canvas, detections);
    }, 100);
});

// "얼굴 추출" 버튼 클릭 이벤트 리스너
document.getElementById('to_img').addEventListener('click', async () => {
    const detections = await faceapi.detectAllFaces(video, new faceapi.TinyFaceDetectorOptions());
    if (detections.length > 0) {
        const detection = detections[0];
        const { x, y, width, height } = detection.box;
        const faceCanvas = document.createElement('canvas');
        faceCanvas.width = width;
        faceCanvas.height = height;
        const faceCanvasCtx = faceCanvas.getContext('2d');
        faceCanvasCtx.drawImage(video, x, y, width, height, 0, 0, width, height);

        // 추출된 이미지를 표시
        const extractedImageDataURL = faceCanvas.toDataURL();
        const imgElement = document.createElement('img');
        imgElement.src = extractedImageDataURL;
        const extractImg = document.getElementById('img_data');
        extractImg.appendChild(imgElement);
    }
});


//출석부에 저장될 데이터 초기 배열값
let data = [
    ["학과","학번","이름"]
];

//저장 버튼눌러서 텍스트와 사진 저장
function saveData() {
    let imgElement = document.getElementById('img_data').querySelector("img");
    let imgData = imgElement ? imgElement.src : "";
    let classData = document.getElementById("class").value;
    let numData = document.getElementById("num").value;
    let nameData = document.getElementById("name").value;

    let student = [
        classData,
        numData,
        nameData
    ];
    //data변수에 값 변수 Student값을 추가해 새로운 행을 생성(엑셀에서 밑으로 생성)
    data.push(student);

    //입력후 저장 버튼 누르면 텍스트상자 빈값으로 초기화
    if (imgElement) {
        imgElement.remove();
    }
    document.getElementById("class").value = "";
    document.getElementById("num").value = "";
    document.getElementById("name").value = "";

    //새로운 파일 생성하여 출석인의 정보 표시
    let newWindow = window.open('', '_blank');
    newWindow.document.write('<img src="'+imgData+'"alt="출석자 이미지">'+'<br>'+"학과: "+classData+'<br>'+"학번: " + numData+'<br>'+"이름: "+nameData);
}

//엑셀 파일 다운로드
document.getElementById("download-btn").addEventListener("click", function() {
    let workbook = XLSX.utils.book_new();
    let worksheet = XLSX.utils.aoa_to_sheet(data);
    XLSX.utils.book_append_sheet(workbook, worksheet, "Sheet1");
    let excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" });

    let blob = new Blob([excelBuffer], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
    let url = URL.createObjectURL(blob);
    let a = document.createElement("a");
    a.href = url;
    a.download = "출석 명단.xlsx";
    document.body.appendChild(a);
    a.click();
    setTimeout(function() {
    document.body.removeChild(a);
    URL.revokeObjectURL(url);  
    }, 0);
});